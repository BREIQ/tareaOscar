<?php

// Configuración de MongoDB
define('MONGODB_URI', 'mongodb://localhost:27017');
define('MONGODB_DATABASE', 'asistencia_app');

// Configuración de administrador
define('ADMIN_PASSWORD', 'Oscar9234');

// Zona horaria
date_default_timezone_set('America/Mexico_City');
